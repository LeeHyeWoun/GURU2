package com.example.anisssoft.swuclassexam2.Util;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.example.anisssoft.swuclassexam2.Bean.JoinBean;
import com.google.gson.Gson;

public class PrefUtil {
    //저장하는 Preference
    public static void setData(Context context, String key, String value){
        SharedPreferences pref = context.getSharedPreferences("text1",Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(key,value);
        editor.commit();
    }

    //불러오는 Preference
    public static String getData(Context context, String key){
        SharedPreferences pref = context.getSharedPreferences("text1",Activity.MODE_PRIVATE);
        return pref.getString(key,"");
    }

    //JoinBean 용 ----------------------------------------------------------------------------------
    //Json 화하여 JoinBean 을 저장하는 Preference
    public  static void setJoinBean(Context context, JoinBean joinBean){
        Gson gson = new Gson();
        String jsonStr = gson.toJson(joinBean); //String = JoinBean -> Json
        setData(context, "joinBean", jsonStr);//json 저장
    }

    //객체화하여 JoinBean 을 불러오는 Preference
    public  static JoinBean getJoinBean(Context context){
        String jsonStr = getData(context, "joinBean");
        if(jsonStr == null || jsonStr.length() ==0){ return new JoinBean();}
        Gson gson = new Gson();
        JoinBean jbBean = gson.fromJson(jsonStr,JoinBean.class); //JoinBean = String(Json) -> JoinBean
        return jbBean;
    }

    //chkBox 용 ------------------------------------------------------------------------------------
    //체크 여부를 boolean 형식으로 저장하는 Preference
    public static void setDataBoolean(Context context, String key, boolean value){
        SharedPreferences pref = context.getSharedPreferences("text1",Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean(key,value);
        editor.commit();
    }

    //체크 여부를 boolean 형식으로 불러오는 Preference
    public static Boolean getDataBoolean(Context context, String key){
        SharedPreferences pref = context.getSharedPreferences("text1",Activity.MODE_PRIVATE);
        return pref.getBoolean(key,false);
    }

}
