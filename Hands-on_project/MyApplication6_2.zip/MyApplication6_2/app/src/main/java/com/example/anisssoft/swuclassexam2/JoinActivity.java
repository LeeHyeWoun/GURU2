package com.example.anisssoft.swuclassexam2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.anisssoft.swuclassexam2.Bean.JoinBean;
import com.example.anisssoft.swuclassexam2.Util.PrefUtil;
import com.google.gson.Gson;

public class JoinActivity extends AppCompatActivity {
    private EditText edtId, edtPw, edtName, edtEmail;
    private Button btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);
        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPw);
        edtName = findViewById(R.id.edtName);
        edtEmail = findViewById(R.id.edtEmail);
        btnJoin = findViewById(R.id.btnJoin);

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1.JoinBean 에 데이터를 넣는다.
                JoinBean jbBean = new JoinBean();
                jbBean.setId(edtId.getText().toString());
                jbBean.setPw(edtPw.getText().toString());
                jbBean.setName(edtName.getText().toString());
                jbBean.setEmail(edtEmail.getText().toString());

                //2. JoinBean 을 json 문자열로 변환한다. (GSON 라이브러리 추가)
//                Gson gson = new Gson();
//                String jsonStr = gson.toJson(jbBean);

                //3. JSON 문자열 Preference 저장
                PrefUtil.setJoinBean(JoinActivity.this, jbBean);

                //4. 화면을 LoginActivity 로 이동
                Toast.makeText(JoinActivity.this,"회원가입 성공", Toast.LENGTH_LONG).show();

                Intent i = new Intent(JoinActivity.this, LoginActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });

    }
}
