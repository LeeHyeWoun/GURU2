package com.example.anisssoft.swuclassexam2.Bean;

import java.io.Serializable;

public class JoinBean implements Serializable { //인텐트에 실어 줍니다.

    private String id;
    private  String pw;
    private  String name;
    private  String email;

    //getter
    public String getId() {return id;}
    public String getPw() {return pw;}
    public String getName() {return name;}
    public String getEmail() { return email;}

    //setter
    public void setId(String id) { this.id = id;}
    public void setPw(String pw) { this.pw = pw;}
    public void setName(String name) { this.name = name;}
    public void setEmail(String email) { this.email = email;}
}
