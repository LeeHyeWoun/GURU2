package com.example.anisssoft.swuclassexam2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.anisssoft.swuclassexam2.Bean.JoinBean;
import com.example.anisssoft.swuclassexam2.Util.PrefUtil;

public class LoginActivity extends AppCompatActivity {

    private EditText edtId, edtPw;
    private CheckBox chkAutoLogin;
    private Button btnLogin, btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPw);
        chkAutoLogin = findViewById(R.id.chkAutoLogin);
        btnLogin = findViewById(R.id.btnLogin);
        btnJoin = findViewById(R.id.btnJoin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //1. 입력된 ID,PW 정보
                String inputId = edtId.getText().toString();
                String inputPw = edtPw.getText().toString();

                //2. 회원가입된 저장된 정보
                JoinBean jbBean = PrefUtil.getJoinBean(LoginActivity.this);

                //3.로그인 체크
                if(inputId.equals(jbBean.getId())&& inputPw.equals(jbBean.getPw())){
                    //로그인 성공
                    if(chkAutoLogin.isChecked()) {
                        Toast.makeText(LoginActivity.this,
                                "자동로그인이 체크 되었습니다.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this,
                                "자동로그인이 체크되어있지 않습니다.", Toast.LENGTH_SHORT).show();
                    }
                    PrefUtil.setDataBoolean(LoginActivity.this, "auto", chkAutoLogin.isChecked());
                    Intent i =  new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(i);
                    finish();
                }
                else{
                    Toast.makeText(LoginActivity.this,"일치하는 정보가 없습니다.", Toast.LENGTH_LONG).show();
                }

            }
        });

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(LoginActivity.this, JoinActivity.class);
                startActivity(j);
                PrefUtil.setDataBoolean(LoginActivity.this, "auto", false);
            }
        });
    }//end OnCreate();

    @Override
    protected void onResume() {
        super.onResume();
        //자동 로그인이 체크되어 있는지 확인
        boolean isAutoLoginChecked = PrefUtil.getDataBoolean(LoginActivity.this,"auto");
        if(isAutoLoginChecked){
//            Intent i = new Intent(LoginActivity.this, MainActivity.class);
//            startActivity(i);
//            finish();

            JoinBean jbBean = PrefUtil.getJoinBean(LoginActivity.this);
            edtId.setText(jbBean.getId());
            edtPw.setText(jbBean.getPw());
            chkAutoLogin.setChecked(true);
        }
    }
}
