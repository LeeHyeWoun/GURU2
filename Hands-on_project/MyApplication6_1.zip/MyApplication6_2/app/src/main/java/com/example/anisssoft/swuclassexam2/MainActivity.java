package com.example.anisssoft.swuclassexam2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.anisssoft.swuclassexam2.Bean.JoinBean;
import com.example.anisssoft.swuclassexam2.Util.PrefUtil;

public class MainActivity extends AppCompatActivity {

    private TextView txtId, txtPw, txtName, txtEmail;
    private  Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtId = findViewById(R.id.txtId);
        txtPw = findViewById(R.id.txtPw);
        txtName = findViewById(R.id.txtName);
        txtEmail = findViewById(R.id.txtEmail);
        btnLogout = findViewById(R.id.btnLogout);

        //가입 정보
        JoinBean jbBean = PrefUtil.getJoinBean(MainActivity.this);

        txtId.setText(jbBean.getId());
        txtPw.setText(jbBean.getPw());
        txtName.setText(jbBean.getName());
        txtEmail.setText(jbBean.getEmail());

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //자동 로그인 해제
                //PrefUtil.setDataBoolean(MainActivity.this, "auto", false);
                //로그인 화면으로 이동
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}
