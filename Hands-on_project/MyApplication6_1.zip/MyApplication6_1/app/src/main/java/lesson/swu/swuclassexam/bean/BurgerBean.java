package lesson.swu.swuclassexam.bean;

public class BurgerBean {
    private int imgTitle;   //이미지
    private String title;   //타이틀
    private String desc;    //설명
    private String price;   //가격

    //Getter
    public int getImgTitle() {return imgTitle;}
    public String getTitle() { return title;}
    public String getDesc() { return desc;}
    public String getPrice() { return price;}

    //Setter
    public void setImgTitle(int imgTitle) { this.imgTitle = imgTitle;}
    public void setTitle(String title) { this.title = title;}
    public void setDesc(String desc) { this.desc = desc;}
    public void setPrice(String price) { this.price = price;}
}
