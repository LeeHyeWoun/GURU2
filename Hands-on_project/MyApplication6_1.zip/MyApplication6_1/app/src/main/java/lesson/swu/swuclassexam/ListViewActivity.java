package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import lesson.swu.swuclassexam.Adapter.BurgerAdapter;
import lesson.swu.swuclassexam.bean.BurgerBean;

public class ListViewActivity extends AppCompatActivity {

    private ListView lstMain;
    private Button btn1,btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        lstMain = findViewById(R.id.lstMain);

        BurgerBean b1 = new BurgerBean();
        b1.setImgTitle(R.drawable.burger1);
        b1.setTitle("인크레더블버거");
        b1.setDesc("크고 확실한 행복을 즐길 수 있는 대확행 버거");
        b1.setPrice("4,900원");

        BurgerBean b2 = new BurgerBean();
        b2.setImgTitle(R.drawable.burger2);
        b2.setTitle("딥치즈버거");
        b2.setDesc("부드러운 치즈와 한층 더 촉촉해진 닭가슴살로 딥~하게 빠져드는 버거");
        b2.setPrice("4,000원");

        BurgerBean b3 = new BurgerBean();
        b3.setImgTitle(R.drawable.burger3);
        b3.setTitle("치킨커틀렛버거");
        b3.setDesc("두툼하고 촉촉한 통 가슴살패티로 색다르게 즐기는 버거");
        b3.setPrice("3,200원");

        List<BurgerBean> burgerList = new ArrayList<BurgerBean>();
        burgerList.add(b1);
        burgerList.add(b2);
        burgerList.add(b3);

        //Adapter 생성
        BurgerAdapter burgerAdapter = new BurgerAdapter(ListViewActivity.this, burgerList);

        lstMain.setAdapter(burgerAdapter);


    }
}
