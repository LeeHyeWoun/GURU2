package lesson.swu.swuclassexam;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

public class InflateActivity extends AppCompatActivity {

    private Button btnInfl1, btnInfl2;
    private FrameLayout franlnfl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inflat);

        btnInfl1 = findViewById(R.id.btnInfl1);
        btnInfl2 = findViewById(R.id.btnInfl2);
        franlnfl = findViewById(R.id.franlnfl);

        btnInfl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inflate1();
            }
        });
        btnInfl2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inflate2();
            }
        });
    }//end OnCreate()

    private void inflate1(){
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //동적으로 로딩한 레이아웃
        View view1 = inflater.inflate(R.layout.view_infl1,null);//FrameLayout 에 붙인다.

        Button btnShow = view1.findViewById(R.id.btnShow);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(InflateActivity.this, "infl1 btn",Toast.LENGTH_SHORT).show();
            }
        });

        franlnfl.removeAllViews();  //붙어있는 모든 뷰를 지우고
        franlnfl.addView(view1);    //새로운 동적뷰를 붙인다.
    }
    private void inflate2(){
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //동적으로 로딩한 레이아웃
        View view1 = inflater.inflate(R.layout.view_infl2,null);//FrameLayout 에 붙인다.
        franlnfl.removeAllViews();  //붙어있는 모든 뷰를 지우고
        franlnfl.addView(view1);    //새로운 동적뷰를 붙인다.
    }
}
