package lesson.swu.swuclassexam.Adapter;

import android.app.ListActivity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import lesson.swu.swuclassexam.ListViewActivity;
import lesson.swu.swuclassexam.R;
import lesson.swu.swuclassexam.bean.BurgerBean;

public class BurgerAdapter extends BaseAdapter {

    private  Context mContext;
    private List<BurgerBean>mList;

    //생성자
    public BurgerAdapter(Context context, List<BurgerBean> list){
        mContext = context;
        mList = list;
    }

    @Override
    public int getCount() { return mList.size();}
    @Override
    public Object getItem(int position) {return position;}
    @Override
    public long getItemId(int position) {return position;}
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.view_burgger,null);

        BurgerBean burgerBean = mList.get(position);

        ImageView imgTitle = convertView.findViewById(R.id.imgTitle);
        final TextView txtTitle = convertView.findViewById(R.id.txtTitle);
        TextView txtDecs = convertView.findViewById(R.id.txtDesc);
        TextView txtPrice = convertView.findViewById(R.id.txtPrice);

        imgTitle.setImageResource(burgerBean.getImgTitle());
        txtTitle.setText(burgerBean.getTitle());
        txtDecs.setText(burgerBean.getDesc());
        txtPrice.setText(burgerBean.getPrice());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext,txtTitle.getText().toString()+"를 선택하셨습니다.",Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }//end getView()
}
