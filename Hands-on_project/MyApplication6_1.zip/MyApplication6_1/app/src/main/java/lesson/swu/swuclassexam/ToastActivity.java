package lesson.swu.swuclassexam;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ToastActivity extends AppCompatActivity {

    //멤버변수자리
    private EditText edtToast;
    private Button btnToast, btnDlg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toast);

        edtToast = findViewById(R.id.edtToast);
        btnToast = findViewById(R.id.btnToast);
        btnDlg = findViewById(R.id.btnDlg);

        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ToastActivity.this,
                        edtToast.getText().toString(), Toast.LENGTH_LONG).show();

            }
        });

        btnDlg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ToastActivity.this);
                builder.setTitle("안내");
                builder.setIcon(R.drawable.eraser);
                builder.setMessage("저를 좋아하십니까?");
                builder.setCancelable(false);

                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ToastActivity.this,
                                "예를 선택 하셨습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("아니오", null);
                builder.create().show();
            }
        });
    }
}
