package lesson.swu.tabfinaltest;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CameraActivity extends AppCompatActivity {

    private Button btnCamera;
    private ImageView imgCamera;
    private String mCurrebrPhotoPath;
    private Uri mImageURI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        //코드상으로 명시적으로 퍼미션을 요청하지 않으면 롤리팝이상...
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
                }, 1);

        btnCamera = findViewById(R.id.btnCamera);
        imgCamera = findViewById(R.id.imgCamera);

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureCamera();
            }
        });
    }//end OnCreate()

    private void captureCamera(){
        String state = Environment.getExternalStorageState();
        if(Environment.MEDIA_MOUNTED.equals(state)) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                try{
                    File photoFile = createImageFile();

                    if(photoFile !=null){
                        Uri providerURI = FileProvider.getUriForFile(this,getPackageName(),photoFile);
                        mImageURI = providerURI;

                        //인텐트에 전달할 때는 FileProviider 의 Return값이 content로만
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,providerURI);

                        //롤리팝 이상의 버전에서만
                        startActivityForResult(takePictureIntent, 2222);
                        }

                }catch(Exception e){
                    Log.e("SWU", e.toString());
                }


            }
        }
    }//end captureCamera()

    //카메라를 찍기전에 카메라로 찍은 이미지가 저장된 파일을 생성-반환한다.
    private File createImageFile() throws Exception{
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String imageFileName = "JPGE_"+timeStamp+".jpg";
        File imagFile = null;
        File storagedir = new File(Environment.getExternalStorageDirectory()+"/Pictures/", "gyeom");

        if(!storagedir.exists()){
            Log.d("SWU", storagedir.toString());
            storagedir.mkdirs();
        }

        imagFile = new File(storagedir, imageFileName);
        mCurrebrPhotoPath = imagFile.getAbsolutePath();

        return imagFile;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode){
            case 2222:
                if(resultCode==Activity.RESULT_OK){
                    try{
                        //카메라로부터 넘어온 데이터를 받는다.
                        imgCamera.setImageURI(mImageURI);
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                }
        }
    }
}//end class
