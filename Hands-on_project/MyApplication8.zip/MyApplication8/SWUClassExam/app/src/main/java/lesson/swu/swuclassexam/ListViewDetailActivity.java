package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import lesson.swu.swuclassexam.bean.BurgerBean;

public class ListViewDetailActivity extends AppCompatActivity {

    private ImageView imgTitle;
    private TextView txtTitle, txtDesc, txtPrice;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_detail);

        //0.View를 찾는다.
        imgTitle  = findViewById(R.id.imgTitle);
        txtTitle = findViewById(R.id.txtTitle);
        txtDesc = findViewById(R.id.txtDesc);
        txtPrice = findViewById(R.id.txtPrice);
        btnBack = findViewById(R.id.btnBack);

        //1.넘겨준 데이터를 받는다.
        BurgerBean burgerBean = (BurgerBean)
                                getIntent().getSerializableExtra(BurgerBean.class.getName());
        if(burgerBean != null) {
            //화면에 표시한다.
            imgTitle.setImageResource( burgerBean.getImgTitle() );
            txtTitle.setText( burgerBean.getTitle() );
            txtDesc.setText( burgerBean.getDesc() );
            txtPrice.setText( burgerBean.getPrice() );
        }

        //돌아가기 버튼 클릭 이벤트
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
