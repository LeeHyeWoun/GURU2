package lesson.swu.swuclassexam;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class IntentTelActivity extends AppCompatActivity {

    private EditText edtTel, edtUrl;
    private Button btnTel, btnUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_tel);

        //requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1000);

        btnTel = findViewById(R.id.btnTel);
        btnUrl = findViewById(R.id.btnUrl);
        edtTel = findViewById(R.id.edtTel);
        edtUrl = findViewById(R.id.edtUrl);

        btnTel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //입력된 전화번호를 가지고 온다.
                String tel = edtTel.getText().toString();
                Intent i = new Intent(Intent.ACTION_DIAL); //전화걸기
                i.setData( Uri.parse("tel:" + tel) );
                startActivity(i);
            }
        });

        btnUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = edtUrl.getText().toString();
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i); //브라우져 실행
            }
        });
    }
}
