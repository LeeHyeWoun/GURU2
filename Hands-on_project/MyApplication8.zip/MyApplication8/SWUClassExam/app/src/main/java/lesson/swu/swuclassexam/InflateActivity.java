package lesson.swu.swuclassexam;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

public class InflateActivity extends AppCompatActivity {

    private Button btnInfl1, btnInfl2;
    private FrameLayout fraInfl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inflate);

        btnInfl1 = findViewById(R.id.btnInfl1);
        btnInfl2 = findViewById(R.id.btnInfl2);
        fraInfl = findViewById(R.id.fraInfl);

        btnInfl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inflate1();
            }
        });

        btnInfl2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inflate2();
            }
        });
    }//end onCreate()

    private void inflate1() {
        LayoutInflater inflater = (LayoutInflater)
                                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //동적으로 로딩한 layout
        View view1 = inflater.inflate(R.layout.view_infl1, null);

        Button btnShow = view1.findViewById(R.id.btnShow);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(InflateActivity.this,
                        "인플레이트1 버튼클릭", Toast.LENGTH_SHORT).show();
            }
        });
        
        //어디다가 붙인다? ==> FrameLayout 에 붙인다.
        fraInfl.removeAllViews(); //붙어있는 모든 뷰들을 지우고
        fraInfl.addView(view1); //새로운 동적뷰를 붙인다.
    }

    private void inflate2() {
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //동적으로 로딩한 layout
        View view1 = inflater.inflate(R.layout.view_infl2, null);
        //어디다가 붙인다? ==> FrameLayout 에 붙인다.
        fraInfl.removeAllViews(); //붙어있는 모든 뷰들을 지우고
        fraInfl.addView(view1); //새로운 동적뷰를 붙인다.
    }

}
