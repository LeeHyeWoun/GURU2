package lesson.swu.swuclassexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class IntentDataActivity extends AppCompatActivity {

    private EditText edtName, edtAge;
    private Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_data);

        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //데이터를 전송하기 위해서
                Intent i = new Intent(IntentDataActivity.this, IntentDataViewActivity.class);
                i.putExtra("name", edtName.getText().toString());
                i.putExtra("age", edtAge.getText().toString());
                startActivity(i);
            }
        });
    }


}
