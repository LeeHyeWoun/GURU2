package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import lesson.swu.swuclassexam.bean.JoinBean;
import lesson.swu.swuclassexam.util.PrefUtil;

public class LoginActivity extends AppCompatActivity {

    private EditText edtId, edtPw;
    private Button btnJoin, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPw);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //로그인 버튼을 누르면, Preference에 저장된 회원 데이터를
                //읽어와서 회원데이터의 ID, PW 값과 현재 입력받은
                //ID, PW 값을 비교한다.
                String jsonData =
                        PrefUtil.getData(getApplicationContext(), JoinBean.class.getName());
                if (jsonData == null || jsonData.length() == 0) {
                    //회원가입된 데이터가 없다.
                    Toast.makeText(LoginActivity.this,
                            "회원가입이 되어 있지 않습니다.", Toast.LENGTH_LONG).show();
                } else {
                    //Json ==> JoinBean 변환
                    Gson gson = new Gson();
                    JoinBean jbBean = gson.fromJson(jsonData, JoinBean.class);

                    String ipId = edtId.getText().toString();
                    String ipPw = edtPw.getText().toString();

                    if( ipId.equals(jbBean.getId()) &&  ipPw.equals(jbBean.getPw()) ) {
                        //로그인 성공

                    } else {
                        //로그인 실패
                        Toast.makeText(LoginActivity.this,
                                "로그인에 실패 하였습니다.", Toast.LENGTH_SHORT).show();

                    }

                }

            }
        });
    }


}
