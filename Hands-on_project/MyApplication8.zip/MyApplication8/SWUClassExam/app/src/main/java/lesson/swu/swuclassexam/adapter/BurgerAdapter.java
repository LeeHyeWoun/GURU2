package lesson.swu.swuclassexam.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import lesson.swu.swuclassexam.ListViewDetailActivity;
import lesson.swu.swuclassexam.R;
import lesson.swu.swuclassexam.bean.BurgerBean;

public class BurgerAdapter extends BaseAdapter {

    private Context mContext;
    private List<BurgerBean> mList;

    //생성자
    public BurgerAdapter(Context context, List<BurgerBean> list) {
        mContext = context;
        mList = list;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //인플레이팅 하는 작업
        LayoutInflater inflater = (LayoutInflater)
                mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.view_burger, null);

        //해당 ROW 의 데이터를 찾는 작업
        final BurgerBean burgerBean = mList.get(position);

        //인플레이팅 된 뷰에서 ID 찾는작업
        ImageView imgTitle = convertView.findViewById( R.id.imgTitle );
        final TextView txtTitle = convertView.findViewById(R.id.txtTitle);
        TextView txtDesc = convertView.findViewById(R.id.txtDesc);
        TextView txtPrice = convertView.findViewById(R.id.txtPrice);

        //데이터 셋팅
        imgTitle.setImageResource( burgerBean.getImgTitle() );
        txtTitle.setText( burgerBean.getTitle() );
        txtDesc.setText( burgerBean.getDesc() );
        txtPrice.setText( burgerBean.getPrice() );

        //이벤트 설정
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i = new Intent(mContext, ListViewDetailActivity.class);
               //선택된 ROW의 Bean 데이터를 싣는다.
               i.putExtra(BurgerBean.class.getName(), burgerBean);
               mContext.startActivity(i); //화면이동
            }
        });

        return convertView;
    }//end getView




}
