package lesson.swu.swuclassexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Button btnGo = findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ThirdActivity.this, ForthActivity.class);
                startActivity(i);
                finish();
            }
        });
        Log.d("SWU", "Thid Activity - onCreate() 실행");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("SWU", "Thid Activity - onStart() 실행");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("SWU", "Thid Activity - onResume() 실행");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("SWU", "Thid Activity - onPause() 실행");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("SWU", "Thid Activity - onStop() 실행");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("SWU", "Thid Activity - onDestroy() 실행");
    }
}
