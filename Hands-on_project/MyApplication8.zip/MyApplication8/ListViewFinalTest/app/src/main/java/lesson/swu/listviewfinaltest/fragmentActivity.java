package lesson.swu.listviewfinaltest;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import lesson.swu.listviewfinaltest.fragment.MovieFragment;
import lesson.swu.listviewfinaltest.fragment.MusicFragment;

public class fragmentActivity extends AppCompatActivity {

    private FrameLayout fraMain;
    private Button btnMusic, btnMovie;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        fraMain = findViewById(R.id.fraMain);
        btnMusic = findViewById(R.id.btnMusic);
        btnMovie = findViewById(R.id.btnMovie);

        btnMusic.setOnClickListener(btnMusicClick);
        btnMovie.setOnClickListener(btnMusicClick);
    }//end onCreate()

    private View.OnClickListener btnMusicClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Fragment fragment = null;

            switch (v.getId()){
                case R.id.btnMusic :
                    fragment = new MusicFragment();
                    break;
                case R.id.btnMovie:
                    fragment = new MovieFragment();
                    break;
            }

            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.fraMain, fragment);
            transaction.commit();
        }
    };
}
