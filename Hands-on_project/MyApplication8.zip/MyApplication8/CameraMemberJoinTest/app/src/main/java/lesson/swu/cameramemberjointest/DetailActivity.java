package lesson.swu.cameramemberjointest;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import lesson.swu.cameramemberjointest.util.PrefUtil;

public class DetailActivity extends AppCompatActivity {

    private ImageView imgProfile;
    private TextView txtName,txtPw;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        imgProfile = findViewById(R.id.imgProfile);
        txtName = findViewById(R.id.txtName);
        txtPw = findViewById(R.id.txtPw);
        btnBack = findViewById(R.id.btnBack);

        //Preference 에 저장된 JSON 을 꺼내온다.
        String jsonStr = PrefUtil.getData(DetailActivity.this, "member");
        Gson gson = new Gson();
        MemberBean mbBean = gson.fromJson(jsonStr,MemberBean.class);

        //저장된 이미지 경로를 가져온다.
        imgProfile.setImageURI(Uri.parse(mbBean.getPhotoImgPath()));
        txtName.setText(mbBean.getName());
        txtPw.setText(mbBean.getPw());

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
