package lesson.swu.cameramemberjointest;

public class MemberBean {
    private String photoImgPath;
    private String name;
    private String pw;

    //getter
    public String getPhotoImgPath() {
        return photoImgPath;
    }

    public String getName() {
        return name;
    }

    public String getPw() {
        return pw;
    }

    //setter

    public void setPhotoImgPath(String photoImgPath) {
        this.photoImgPath = photoImgPath;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }
}
