package lesson.swu.swuclassexam2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import lesson.swu.swuclassexam2.Bean.JoinBean;
import lesson.swu.swuclassexam2.Util.PrefUtil;

public class LoginActivity extends AppCompatActivity {

    private CheckBox chkAotoLogin;
    private EditText edtId,edtPw;
    private Button btnLogin, btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        chkAotoLogin = findViewById(R.id.chkAotoLogin);
        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPw);
        btnLogin = findViewById(R.id.btnLogin);
        btnJoin = findViewById(R.id.btnJoin);

        if(PrefUtil.getDataBoolean(LoginActivity.this, "bool" )){
            //데이터를 'Preference'로 저장한다.
            // 'preference'에 저장된 회원데이터를 읽어와서 회원데이터의 ID,PW 값과 현재 입력받은 ID,PW를 비교한다.
            String jsonData = PrefUtil.getData(LoginActivity.this, JoinBean.class.getName());
            //json ->JoinBean
            Gson gSon = new Gson();
            JoinBean jbBean = gSon.fromJson(jsonData, JoinBean.class);
            edtId.setText(jbBean.getId());
            edtPw.setText(jbBean.getPw());
        }

        chkAotoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chkAotoLogin.isChecked()){
                    Toast.makeText(LoginActivity.this, "자동로그인이 체크 되었습니다.", Toast.LENGTH_SHORT).show();
                    if(chkAotoLogin.isChecked()){
                        PrefUtil.setData(LoginActivity.this, "bool", true);
                    }
                }
                else{
                    Toast.makeText(LoginActivity.this, "자동로그인이 해제 되었습니다.", Toast.LENGTH_SHORT).show();
                    if(chkAotoLogin.isChecked()){
                        PrefUtil.setData(LoginActivity.this, "bool", false);
                    }
                }
            }
        });

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this,JoinOkActivity.class);
                //회원가입 데이터 객체 생성
                JoinBean jb = new JoinBean();
                //회원가입 데이터 설정
                jb.setId(edtId.getText().toString());       // i.putExtra("id",edtId.getText().toString());
                jb.setPw(edtPw.getText().toString());       // i.putExtra("pw",edtPw.getText().toString());
                //데이터를 'Preference'로 저장한다.
                //JoinBean class ==> 'string'화 ==>'json'화
                Gson gson = new Gson();
                String jsonStr = gson.toJson(jb);
                Log.i("SWU",jsonStr);
                PrefUtil.setData(LoginActivity.this, JoinBean.class.getName(),jsonStr);

                startActivity(i);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        });

    }
}
