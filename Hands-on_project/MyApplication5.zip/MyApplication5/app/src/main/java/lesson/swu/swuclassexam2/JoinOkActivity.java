
package lesson.swu.swuclassexam2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import lesson.swu.swuclassexam2.Bean.JoinBean;

public class JoinOkActivity extends AppCompatActivity {

    private TextView txtId,txtPw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_ok);

        //인텐트로 부터 온 데이터를 취득
        JoinBean joinBean = (JoinBean) getIntent().getSerializableExtra(JoinBean.class.getName());

        txtId = findViewById(R.id.txtId);
        txtPw = findViewById(R.id.txtPw);

        txtId.setText(joinBean.getId());
        txtPw.setText(joinBean.getPw());
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
