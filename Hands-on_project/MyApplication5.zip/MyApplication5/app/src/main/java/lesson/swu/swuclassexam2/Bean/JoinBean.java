package lesson.swu.swuclassexam2.Bean;

import java.io.Serializable;

/**
 * 회원가입 데이터 Bean
 */
public class JoinBean implements Serializable {//직렬화

    //멤버변수 선언
    private String id;      //아이디
    private String pw;      //패스워드
    private String name;    //이름
    private String email;   //이메일 주소
    private String age;     //나이
    private String hp;      //핸드폰 번호
    private String addr;    //주소

    //getter
    public String getId() { return id;}
    public String getPw() { return pw;}
    public String getName() { return name;}
    public String getEmail() { return email;}
    public String getAge() { return age;}
    public String getHp() { return hp;}
    public String getAddr() { return addr;}

    //setter
    public void setId(String id) { this.id = id;}
    public void setPw(String pw) { this.pw = pw;}
    public void setName(String name) { this.name = name;}
    public void setEmail(String email) { this.email = email;}
    public void setAge(String age) { this.age = age;}
    public void setHp(String hp) { this.hp = hp;}
    public void setAddr(String addr) { this.addr = addr;}
}
