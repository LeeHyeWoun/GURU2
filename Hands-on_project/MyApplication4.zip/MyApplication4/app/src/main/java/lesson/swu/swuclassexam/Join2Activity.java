package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Join2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join2);

        String id = getIntent().getStringExtra("id");
        String pw = getIntent().getStringExtra("pw");
        String name = getIntent().getStringExtra("name");
        String email = getIntent().getStringExtra("email");

        TextView txtId = findViewById(R.id.txtId);
        TextView txtPw = findViewById(R.id.txtPw);
        TextView txtName = findViewById(R.id.txtName);
        TextView txtEmail = findViewById(R.id.txtEmail);

        txtId.setText("ID : "+id);
        txtPw.setText("PW : "+pw);
        txtName.setText("Name : "+name);
        txtEmail.setText("E_mail : "+email);


    }
}
