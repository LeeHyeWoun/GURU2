package lesson.swu.swuclassexam;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ToastActivity extends AppCompatActivity {

    //멤버변수 선언
    private Button btnToast, btnDlg;
    private EditText edtToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toast);

        //변수 정의
        btnToast = findViewById(R.id.btnToast);
        btnDlg = findViewById(R.id.btnDlg);
        edtToast = findViewById(R.id.edtToast);

        //이벤트 등록
        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ToastActivity.this,edtToast.getText().toString(), Toast.LENGTH_LONG).show();
            }
        });
        btnDlg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ToastActivity.this);
                builder.setTitle("안내");
                builder.setIcon(R.drawable.eraser);
                builder.setMessage("저를 좋아하십니까?");
                builder.setCancelable(false);
                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ToastActivity.this,"감사합니다 :D",Toast.LENGTH_LONG).show();
                    }
                });
                builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ToastActivity.this,"유감이네요 :(",Toast.LENGTH_LONG).show();
                    }
                });
                builder.create().show();
            }
        });
    }
}
