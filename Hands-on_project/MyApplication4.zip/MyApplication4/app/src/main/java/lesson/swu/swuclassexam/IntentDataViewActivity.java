package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class IntentDataViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_data_view);

        //데이터 수신
        String name = getIntent().getStringExtra("name");
        String age = getIntent().getStringExtra("age");

        //데이터 변수 선언 및 정의
        TextView txtName = findViewById(R.id.txtName);
        TextView txtAge = findViewById(R.id.txtAge);

        //데이터 설정
        txtName.setText("이름: "+name);
        txtAge.setText("나이: "+age);
    }
}
