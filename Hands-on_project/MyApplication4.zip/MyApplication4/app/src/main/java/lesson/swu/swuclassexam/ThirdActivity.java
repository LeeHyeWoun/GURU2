package lesson.swu.swuclassexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Button btnGo = findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ThirdActivity.this, ForthActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }
        });

        Log.i("SWU","Third Activity - OnCreate 실행");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("SWU","Third Activity - OnStart 실행");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("SWU","Third Activity - OnResume 실행");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("SWU","Third Activity - OnPause 실행");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("SWU","Third Activity - OnStop 실행");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("SWU","Third Activity - OnDestroy 실행");
    }
}
