package lesson.swu.listviewfinaltest;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import lesson.swu.listviewfinaltest.Bean.SoccerBean;

public class DetailActivity extends AppCompatActivity {
    private ImageView imgTitle, img1,img2,img3;
    private Button btnBefore, btnBack, btnNext;
    private TextView txtName, txtPosition, txtAge, txtBelong, txtSalary;

    SoccerBean soccerBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //엑티비티를 전체화면으로 열기
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_detail);

        //ID 찾기
        imgTitle = findViewById(R.id.imgTitle);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
        btnBefore = findViewById(R.id.btnBefore);
        btnBack = findViewById(R.id.btnBack);
        btnNext = findViewById(R.id.btnNext);
        txtName = findViewById(R.id.txtName);
        txtPosition = findViewById(R.id.txtPosition);
        txtAge = findViewById(R.id.txtAge);
        txtBelong = findViewById(R.id.txtBelong);
        txtSalary = findViewById(R.id.txtSalary);

        //1.넘겨준 데이터를 받는다.
        soccerBean = (SoccerBean) getIntent().getSerializableExtra(SoccerBean.class.getName());

        //데이터 설정
        if(soccerBean !=null){
            //이미지
            imgTitle.setImageResource(soccerBean.getImgTitle());
            img1.setImageResource(soccerBean.getImgTitle());
            img2.setImageResource(soccerBean.getImg2());
            img3.setImageResource(soccerBean.getImg3());
            //텍스트
            txtName.setText(soccerBean.getName());
            txtPosition.setText(soccerBean.getPosition());
            txtAge.setText(soccerBean.getAge());
            txtBelong.setText(soccerBean.getBelong());
            txtSalary.setText(soccerBean.getSalary());

        }

        //이벤트 설정
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgTitle.setImageResource(soccerBean.getImgTitle());
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgTitle.setImageResource(soccerBean.getImg2());
            }
        });
        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgTitle.setImageResource(soccerBean.getImg3());
            }
        });

        btnBefore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //
            }
        });

    }//end onCreate()
}
