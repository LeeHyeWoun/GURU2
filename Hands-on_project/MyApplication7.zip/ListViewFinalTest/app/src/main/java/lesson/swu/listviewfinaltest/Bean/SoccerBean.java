package lesson.swu.listviewfinaltest.Bean;

import java.io.Serializable;

public class SoccerBean implements Serializable {
    private int imgTitle;
    private int img2;
    private int img3;
    private String name;
    private String position;
    private String age;
    private String belong;
    private String salary;

    //getter
    public int getImgTitle() { return imgTitle;}
    public int getImg2() { return img2;}
    public int getImg3() { return img3;}
    public String getName() { return "이름 : "+name;}
    public String getPosition() { return "포지션 : "+position;}
    public String getAge() { return "나이 : "+age;}
    public String getBelong() { return "소속 : "+belong;}
    public String getSalary() { return "연봉 : "+salary;}

    //setter

    public void setImgTitle(int imgTitle) { this.imgTitle = imgTitle;}
    public void setImg2(int img2) { this.img2 = img2;}
    public void setImg3(int img3) { this.img3 = img3;}
    public void setName(String name) { this.name = name;}
    public void setPosition(String position) { this.position = position;}
    public void setAge(String age) { this.age = age;}
    public void setBelong(String belong) { this.belong = belong;}
    public void setSalary(String salary) { this.salary = salary;}
}
