package lesson.swu.listviewfinaltest.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import lesson.swu.listviewfinaltest.Bean.SoccerBean;
import lesson.swu.listviewfinaltest.DetailActivity;
import lesson.swu.listviewfinaltest.R;

public class SoccerAdapter extends BaseAdapter {
    private Context mContext;
    private List<SoccerBean> mList;

    public SoccerAdapter(Context context, List<SoccerBean> list){
        mContext = context;
        mList = list;
    }

    @Override
    public int getCount() { return mList.size(); }
    @Override
    public Object getItem(int position) { return position;}
    @Override
    public long getItemId(int position) { return position; }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //인플레이팅하는 작업
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.view_soccer,null);

        //해당 ROW 의 데이터를 찾는 작업
        final SoccerBean soccerBean = mList.get(position);

        //인플레이팅 된 뷰에서 ID를 찾는 작업
        ImageView imgTitle = convertView.findViewById(R.id.imgTitle);
        TextView txtName = convertView.findViewById(R.id.txtName);
        TextView txtPosition = convertView.findViewById(R.id.txtPosition);
        TextView txtAge = convertView.findViewById(R.id.txtAge);
        TextView txtBelong = convertView.findViewById(R.id.txtBelong);
        TextView txtSalary = convertView.findViewById(R.id.txtSalary);

        //데어터 세팅
        imgTitle.setImageResource(soccerBean.getImgTitle());
        txtName.setText(soccerBean.getName());
        txtPosition.setText(soccerBean.getPosition());
        txtAge.setText(soccerBean.getAge());
        txtBelong.setText(soccerBean.getBelong());
        txtSalary.setText(soccerBean.getSalary());

        //이벤트 설정
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext, DetailActivity.class);
                //선택된 ROW 의 Bean 데이터를 싣는다.
                i.putExtra(SoccerBean.class.getName(),soccerBean);
                mContext.startActivity(i);//화면이동
            }
        });

        return convertView;

    }//end getView();
}
