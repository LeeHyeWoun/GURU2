package lesson.swu.listviewfinaltest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import lesson.swu.listviewfinaltest.Adapter.SoccerAdapter;
import lesson.swu.listviewfinaltest.Bean.SoccerBean;

public class MainActivity extends AppCompatActivity {

    private ListView lstMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lstMain = findViewById(R.id.lstMain);

        SoccerBean s1 = new SoccerBean();
        s1.setImgTitle(R.drawable.soccer_hwang);
        s1.setImg2(R.drawable.soccer_hwang_2);
        s1.setImg3(R.drawable.soccer_hwang_3);
        s1.setName("황의조");
        s1.setPosition("FW");
        s1.setAge("1992.08.28");
        s1.setBelong("감바 오사카(일본)");
        s1.setSalary("1억");

        SoccerBean s2 = new SoccerBean();
        s2.setImgTitle(R.drawable.soccer_koo);
        s2.setImg2(R.drawable.soccer_koo_2);
        s2.setImg3(R.drawable.soccer_koo_3);
        s2.setName("구자철");
        s2.setPosition("MF");
        s2.setAge("1989.02.27");
        s2.setBelong("FC 아우크스부르크(독일)");
        s2.setSalary("1억");

        SoccerBean s3 = new SoccerBean();
        s3.setImgTitle(R.drawable.soccer_ji);
        s3.setImg2(R.drawable.soccer_ji_2);
        s3.setImg3(R.drawable.soccer_ji_3);
        s3.setName("지동원");
        s3.setPosition("FW");
        s3.setAge("1991.05.28");
        s3.setBelong("FC 아우크스부르크(독일)");
        s3.setSalary("1억");

        SoccerBean s4 = new SoccerBean();
        s4.setImgTitle(R.drawable.soccer_ju);
        s4.setImg2(R.drawable.soccer_ju_2);
        s4.setImg3(R.drawable.soccer_ju_3);
        s4.setName("주세종");
        s4.setPosition("MF");
        s4.setAge("1990.01.26");
        s4.setBelong("아산무둥화 FC");
        s4.setSalary("1억");

        SoccerBean s5 = new SoccerBean();
        s5.setImgTitle(R.drawable.soccer_jung);
        s5.setImg2(R.drawable.soccer_jung_2);
        s5.setImg3(R.drawable.soccer_jung_3);
        s5.setName("정우영");
        s5.setPosition("MF");
        s5.setAge("1989.12.14");
        s5.setBelong("알 사드(카타르)");
        s5.setSalary("1억");

        SoccerBean s6 = new SoccerBean();
        s6.setImgTitle(R.drawable.soccer_ki);
        s6.setImg2(R.drawable.soccer_ki_2);
        s6.setImg3(R.drawable.soccer_ki_3);
        s6.setName("기성용");
        s6.setPosition("FW");
        s6.setAge("1989.01.24");
        s6.setBelong("뉴캐슬 유나이티드(잉글랜드)");
        s6.setSalary("1억");

        SoccerBean s7 = new SoccerBean();
        s7.setImgTitle(R.drawable.soccer_kim);
        s7.setImg2(R.drawable.soccer_kim_2);
        s7.setImg3(R.drawable.soccer_kim_3);
        s7.setName("김민재");
        s7.setPosition("DF");
        s7.setAge("1996.11.15");
        s7.setBelong("전북현대모터스");
        s7.setSalary("1억");

        SoccerBean s8 = new SoccerBean();
        s8.setImgTitle(R.drawable.soccer_lee);
        s8.setImg2(R.drawable.soccer_lee_2);
        s8.setImg3(R.drawable.soccer_lee_3);
        s8.setName("이청용");
        s8.setPosition("MF");
        s8.setAge("1988.07.02");
        s8.setBelong("Vfl 보훔(독일)");
        s8.setSalary("1억");

        SoccerBean s9 = new SoccerBean();
        s9.setImgTitle(R.drawable.soccer_na);
        s9.setImg2(R.drawable.soccer_na_2);
        s9.setImg3(R.drawable.soccer_na_3);
        s9.setName("나상호");
        s9.setPosition("MF");
        s9.setAge("1996.08.12");
        s9.setBelong("광주 FC");
        s9.setSalary("1억");

        SoccerBean s10 = new SoccerBean();
        s10.setImgTitle(R.drawable.soccer_son);
        s10.setImg2(R.drawable.soccer_son_2);
        s10.setImg3(R.drawable.soccer_son_3);
        s10.setName("손흥민");
        s10.setPosition("MF");
        s10.setAge("1992.07.08");
        s10.setBelong("토트넘 훗스퍼(잉글랜드)");
        s10.setSalary("1억");

        List<SoccerBean> soccerList = new ArrayList<SoccerBean>();
        soccerList.add(s1);
        soccerList.add(s2);
        soccerList.add(s3);
        soccerList.add(s4);
        soccerList.add(s5);
        soccerList.add(s6);
        soccerList.add(s7);
        soccerList.add(s8);
        soccerList.add(s9);
        soccerList.add(s10);

        //Adapter 생성
        SoccerAdapter soccerAdapter = new SoccerAdapter(MainActivity.this, soccerList);

        lstMain.setAdapter(soccerAdapter);

    }
}
