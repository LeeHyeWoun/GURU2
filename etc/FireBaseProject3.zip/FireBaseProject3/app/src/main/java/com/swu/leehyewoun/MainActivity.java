package com.swu.leehyewoun;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.gson.Gson;
import com.swu.leehyewoun.bean.LoginBean;
import com.swu.leehyewoun.util.PrefUtil;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    // 비밀번호 정규식
    private static final Pattern PASSWORD_PATTERN = Pattern.compile("^[a-zA-Z0-9!@.#$%^&*?_~]{4,16}$");

    //파이어베이스 인증 객체 생성
    private FirebaseAuth firebaseAuth;
    private EditText edtId, edtPw;
    private Button btnLogin, btnJoin;
    private CheckBox chbAuto;

    //구글 로그인 버튼
    private SignInButton btnGoogleSignIn;
    //구글 api 클라이언트
    private GoogleSignInClient googleSignInClient;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPass);
        chbAuto = findViewById(R.id.chbAuto);
        btnLogin = findViewById(R.id.btnLogin);
        btnJoin = findViewById(R.id.btnJoin);
        btnGoogleSignIn = findViewById(R.id.btnGoogleSinin);

        //자동로그인이 체크되어있을 경우 자동 설정
        if(PrefUtil.getDataBoolean(MainActivity.this, "bool" )){
            //데이터를 'Preference'로 저장한다.
            // 'preference'에 저장된 회원데이터를 읽어와서 회원데이터의 ID,PW 값과 현재 입력받은 ID,PW를 비교한다.
            String jsonData = PrefUtil.getData(MainActivity.this, LoginBean.class.getName());
            //json ->LoginBean
            Gson gSon = new Gson();
            LoginBean lbBean = gSon.fromJson(jsonData, LoginBean.class);
            edtId.setText(lbBean.getId());
            edtPw.setText(lbBean.getPw());

            chbAuto.setChecked(true);
        }

        //이벤트
        //자동로그인
        chbAuto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chbAuto.isChecked()){
                    Toast.makeText(MainActivity.this, "자동로그인이 체크 되었습니다.", Toast.LENGTH_SHORT).show();
                    PrefUtil.setData(MainActivity.this, "bool", true);
                }
                else{
                    Toast.makeText(MainActivity.this, "자동로그인이 해제 되었습니다.", Toast.LENGTH_SHORT).show();
                    PrefUtil.setData(MainActivity.this, "bool", false);
                }
            }
        });

        //회원가입
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = edtId.getText().toString();
                String pw = edtPw.getText().toString();

                //유효성 체크
                if(isValidEmail(id)&&isValidPasswd(pw)){
                    //FireBase 에 회원가입
                    createUser(id,pw);
                }
            }
        });
        //로그인
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //자동 로그인을 위해 현재 로그인하는 정보를 저장
                //로그인 데이터 객체 생성
                LoginBean lb = new LoginBean();
                //로그인 데이터 설정
                lb.setId(edtId.getText().toString());
                lb.setPw(edtPw.getText().toString());
                //데이터를 'Preference'로 저장한다.
                Gson gson = new Gson();
                String jsonStr = gson.toJson(lb);
                PrefUtil.setData(MainActivity.this, LoginBean.class.getName(),jsonStr);

                //유효성 체크
                if(isValidEmail(lb.getId())&&isValidPasswd(lb.getPw())){
                    //로그인
                    loginUser(lb.getId(),lb.getPw());
                }

            }
        });

        //구글 로그인
        btnGoogleSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoogleSignInOptions googleSignInOptions =
                new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_GAMES_SIGN_IN)
                        .requestIdToken(getString(R.string.default_web_client_id)).requestEmail()
                        .build();
                googleSignInClient = GoogleSignIn.getClient(MainActivity.this,googleSignInOptions);
                btnGoogleSignIn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent signIntent = googleSignInClient.getSignInIntent();
                        startActivityForResult(signIntent,100);
                    }
                });

            }
        });
    }//end onCreate()-------------------------------------------------------------------------------

    //회원가입 처리
    private void createUser(String email, String pass){
        firebaseAuth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    //회원가입 성공
                    Toast.makeText(MainActivity.this,"회원가입 성공",Toast.LENGTH_SHORT).show();
                }else{
                    //회원가입 실패
                    Toast.makeText(MainActivity.this,"회원가입 실패",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }//end createUser()

    //로그인 처리
    private void loginUser(String email, String pass){
        //다이얼로그 보이기
        PrefUtil.showProgress(MainActivity.this);

        firebaseAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this,"로그인 성공",Toast.LENGTH_SHORT).show();
                    goBordActivity();
                }else{
                    Toast.makeText(MainActivity.this,"로그인 실패",Toast.LENGTH_SHORT).show();
                }
                //다이얼로그 숨기기
                PrefUtil.hideProgress(MainActivity.this);
            }
        });
    }

    // 이메일 유효성 검사
    private boolean isValidEmail(String email) {
        if (email.isEmpty()) {
            // 이메일 공백
            Toast.makeText(MainActivity.this,"이메일 공백",Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            // 이메일 형식 불일치
            Toast.makeText(MainActivity.this,"이메일 형식 불일치",Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    // 비밀번호 유효성 검사
    private boolean isValidPasswd(String password) {
        if (password.isEmpty()) {
            // 비밀번호 공백
            Toast.makeText(MainActivity.this,"패스워드 공백",Toast.LENGTH_SHORT).show();
            return false;
        } else if (!PASSWORD_PATTERN.matcher(password).matches()) {
            // 비밀번호 형식 불일치
            Toast.makeText(MainActivity.this,"패스워드 형식 불일치",Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100){
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try{
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            }catch (Exception e){e.printStackTrace();}
        }//end if
    }//end onActivityResult

    // 사용자가 정상적으로 로그인한 후에 GoogleSignInAccount 개체에서 ID 토큰을 가져와서
    // Firebase 사용자 인증 정보로 교환하고 Firebase 사용자 인증 정보를 사용해 Firebase에 인증합니다.
    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {

        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 로그인 성공
                            Toast.makeText(MainActivity.this, "로그인 성공", Toast.LENGTH_LONG).show();

                        } else {
                            // 로그인 실패
                            Toast.makeText(MainActivity.this, "로그인 실패", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
    }

    private void goBordActivity(){
        Intent i = new Intent(MainActivity.this,BoardActivity.class);
        startActivity(i);
        finish();
    }

}//end class
