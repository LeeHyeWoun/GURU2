package com.swu.leehyewoun;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.swu.leehyewoun.adapter.BoardAdapter;
import com.swu.leehyewoun.bean.BoardBean;
import com.swu.leehyewoun.util.PrefUtil;

import java.util.ArrayList;
import java.util.List;

public class BoardActivity extends AppCompatActivity {

    private Button btnNew, btnLogout;
    private ListView lstMemo;

    private FirebaseAuth mAuth;
    private FirebaseStorage mStorage;
    private FirebaseDatabase mDatabase;

    private List<BoardBean> mBoardList = new ArrayList<BoardBean>();
    private BoardAdapter mBoardAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);

        btnNew=findViewById(R.id.btnNew);
        btnLogout=findViewById(R.id.btnLogout);
        lstMemo=findViewById(R.id.lstMemo);
        mAuth = FirebaseAuth.getInstance();
        mStorage =FirebaseStorage.getInstance();
        mDatabase=FirebaseDatabase.getInstance();


        btnNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BoardActivity.this,InsertBoardActivity.class);
                startActivity(i);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();

                Intent i = new Intent(BoardActivity.this,MainActivity.class);
                Toast.makeText(BoardActivity.this,"로그아웃 되었습니다.",Toast.LENGTH_SHORT).show();
                startActivity(i);
                finish();
            }
        });

        mBoardAdapter = new BoardAdapter(this,mBoardList);
        lstMemo.setAdapter(mBoardAdapter);

    }//end onCreate


    @Override
    protected void onResume() {
        super.onResume();

        FirebaseAuth mAuth=FirebaseAuth.getInstance();
        //버튼에 사용자 ID 표시
        btnLogout.setText(mAuth.getCurrentUser().getEmail()+"\n로그아웃");

        //데이터 목록을 Firebase 로부터 가져온다.
        String emailUUID = InsertBoardActivity.getUserIdFromUUID(mAuth.getCurrentUser().getEmail());
        mDatabase.getReference().child("memo").child(emailUUID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //실시간으로 서버가 변경된 내용이 있을 경우 호출된다.
                //기존의 리스트는 날려버린다.
                mBoardList.clear();
                //리스트를 서버로부터 온 데이터로 새로 만든다.
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    BoardBean bean = snapshot.getValue(BoardBean.class);
                    mBoardList.add(bean);
                }
                //어뎁터를 갱신하는 메서드를 호출한다.
                mBoardAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }//end onResume
}
