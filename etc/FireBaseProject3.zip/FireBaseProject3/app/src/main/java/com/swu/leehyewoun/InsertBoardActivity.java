package com.swu.leehyewoun;

import android.Manifest;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.swu.leehyewoun.bean.BoardBean;
import com.swu.leehyewoun.util.PrefUtil;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class InsertBoardActivity extends AppCompatActivity {

    //사진이 저장된 경로 : onActivityResult() 로부터 받는 데이터
    private Uri mCaptureUri;
    //사진이 저장된 단말기상의 실제 경로
    private String mPhotoPath;
    //onActivityResult 에서 사용하는 구분값
    public static final int REQUEST_IMAGE_CAPTURE = 200;

    private ImageView imgPhoto;
    private EditText edtTitle, edtMemo;
    private Button btnUpload;

    private FirebaseAuth mAuth;
    private FirebaseStorage mStorage;
    private FirebaseDatabase mDatabase;

    private BoardBean mBoardBean;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_board);

        imgPhoto = findViewById(R.id.imgPhoto);
        edtTitle = findViewById(R.id.edtTitle);
        edtMemo = findViewById(R.id.edtMemo);
        btnUpload = findViewById(R.id.btnUpload);
        mAuth = FirebaseAuth.getInstance();
        mStorage =FirebaseStorage.getInstance();
        mDatabase=FirebaseDatabase.getInstance();

        mBoardBean = (BoardBean) getIntent().getSerializableExtra(BoardBean.class.getName());

        if(mBoardBean!=null){
            //수정
            try{ //비동기 호출
                new DownImgTask(imgPhoto).execute(new URL(mBoardBean.imgUrl));
            }catch (Exception e){e.printStackTrace();}

            edtTitle.setText(mBoardBean.title);
            edtMemo.setText(mBoardBean.content);
            btnUpload.setText("메모 수정");
        }

        //카메라 권한을 위한 퍼미션을 요청한다.
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
        },0);

        //이벤트 설정
        //이미지 뷰 클릭 시 카메라 구동
        imgPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();
            }
        });
        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mBoardBean==null){
                    //신규등록
                    upload(mCaptureUri);
                }
                else{
                    //수정처리
                    update(mCaptureUri);
                }
            }
        });
    }//end onCreate---------------------------------------------------------------------------------

    /***************** 카메라 관련 Functions - Start *****************/
    private void takePicture() {

        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            mCaptureUri = Uri.fromFile( getOutPutMediaFile() );
        } else {
            mCaptureUri = FileProvider.getUriForFile(this,
                    "com.swu.leehyewoun.fileprovider", getOutPutMediaFile());
        }

        i.putExtra(MediaStore.EXTRA_OUTPUT, mCaptureUri);

        //내가 원하는 액티비티로 이동하고, 그 액티비티가 종료되면 (finish되면)
        //다시금 나의 액티비티의 onActivityResult() 메서드가 호출되는 구조이다.
        //내가 어떤 데이터를 받고 싶을때 상대 액티비티를 호출해주고 그 액티비티에서
        //호출한 나의 액티비티로 데이터를 넘겨주는 구조이다. 이때 호출되는 메서드가
        //onActivityResult() 메서드 이다.
        startActivityForResult(i, REQUEST_IMAGE_CAPTURE);

    }

    private File getOutPutMediaFile() {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "cameraDemo");
        if(!mediaStorageDir.exists()) {
            if(!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File file = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");

        mPhotoPath = file.getAbsolutePath();

        return file;
    }

    private void sendPicture(String imgFilePath) {
        Bitmap bitmap = BitmapFactory.decodeFile(imgFilePath);
        Bitmap resizedBmp = getResizedBitmap(bitmap, 4, 100, 100);

        bitmap.recycle();

        //사진이 캡쳐되서 들어오면 뒤집어져 있다. 이애를 다시 원상복구 시킨다.
        ExifInterface exif = null;
        try {
            exif = new ExifInterface(imgFilePath);
        } catch(Exception e) {
            e.printStackTrace();
        }
        int exifOrientation;
        int exifDegree;
        if(exif != null) {
            exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            exifDegree = exifOrientToDegree(exifOrientation);
        } else {
            exifDegree = 0;
        }
        Bitmap rotatedBmp = roate(resizedBmp, exifDegree);
        imgPhoto.setImageBitmap( rotatedBmp );
    }

    private int exifOrientToDegree(int exifOrientation) {
        if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
            return 90;
        }
        else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 180;
        }
        else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
            return 270;
        }
        return 0;
    }

    private Bitmap roate(Bitmap bmp, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(),
                matrix, true);
    }

    //비트맵의 사이즈를 줄여준다.
    public static Bitmap getResizedBitmap(Bitmap srcBmp, int size, int width, int height){
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = size;
        Bitmap resized = Bitmap.createScaledBitmap(srcBmp, width, height, true);
        return resized;
    }

    public static Bitmap getResizedBitmap(Resources resources, int id, int size, int width, int height){
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = size;
        Bitmap src = BitmapFactory.decodeResource(resources, id, options);
        Bitmap resized = Bitmap.createScaledBitmap(src, width, height, true);
        return resized;
    }
    /***************** 카메라 관련 Functions - End *****************/

    /*****************Storage, Database Upload 관련 Function****************************/
    private void upload(final Uri fileUri){
        if(fileUri==null){
            return;
        }
        //image 파일을 파이어베이스 서버에 업로드한다.
        //가장 먼저, Firebase Storgage 인스턴트를 생성한다.
        //storage를 추가하려면 상단에 gs:// 로 시작하는 스키마를 확인할 수 있다.
        FirebaseStorage fs = FirebaseStorage.getInstance("gs://swu2019winterproject-2100f.appspot.com/");
        //위에서 생성한 Firebase Storage 를 참조하는 storage 를 생성한다.
        StorageReference storageReference = fs.getReference();
        //위의 저장소를 참조하는 image 폴더를 저장해서 이미지를 올린다.
        final StorageReference imageref = storageReference.child("images/"+fileUri.getLastPathSegment());
        //실제파일 업로드 진행
        UploadTask uploadTask = imageref.putFile(fileUri);

        //다이얼로그 보이기
        PrefUtil.showProgress(InsertBoardActivity.this);


        //파일 업로드 성공/실패에 대한 콜백 메서드를 받아서 핸들링한다.
        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if(!task.isSuccessful()){
                    throw task.getException();
                }
                //이미지 파일이 올라간 실제 URL 주소를 addOnCompleteListener 에 리턴한다.
                return imageref.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                //이미지 업로드가 끝나면 호출되는 callBack 메서드
                //해야될 일 : Uploaded 된 이미지 URL과 사용자가 작성한
                //메모의 내용을 RealTime DB 에 업로드 시킨다.
                DatabaseReference firebaseRef = mDatabase.getReference();
                String id = firebaseRef.push().getKey();//Key 를 ID로 사용

                //Database 에 저장한다.
                BoardBean boardbean = new BoardBean();
                boardbean.id = id;
                boardbean.userId = mAuth.getCurrentUser().getEmail();
                boardbean.imgUrl=task.getResult().toString();
                boardbean.imgName = fileUri.getLastPathSegment();//파일 이름 저장
                boardbean.title=edtTitle.getText().toString();
                boardbean.content=edtMemo.getText().toString();

                //userEmail 의 고유번호를 기준으로 사용자 데이터를 쌓기위해
                //고유키를 생성한다.
                String userUUID = getUserIdFromUUID(boardbean.userId);
                firebaseRef.child("memo").child(userUUID).child(boardbean.id).setValue(boardbean);

                Toast.makeText(InsertBoardActivity.this,"서버로 메모 글쓰기 성공",Toast.LENGTH_SHORT).show();

                //다이얼로그 숨기기
                PrefUtil.hideProgress(InsertBoardActivity.this);
                finish();
            }
        });

    }//end Upload

    //수정처리
    private void update(final Uri fileUri){
        //사진을 찍지 않고 수정버튼을 눌렀을 경우는, fileUri 가 null 이 온다.
        if(fileUri==null){
            String emailUUID = getUserIdFromUUID(mBoardBean.userId);

            //수정할 데이터를 Bean 에 바꿔 넣는다
            mBoardBean.title = edtTitle.getText().toString();
            mBoardBean.content = edtMemo.getText().toString();
            //서버에 수정처리
            mDatabase.getReference().child("memo").child(emailUUID).child(mBoardBean.id).setValue(mBoardBean);

            Toast.makeText(InsertBoardActivity.this,"수정되었습니다.",Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        //사진을 변경했을 때의 처리
        //사진을 서버에 업로드한다
        //image 파일을 파이어베이스 서버에 업로드한다.
        //가장 먼저, Firebase Storgage 인스턴트를 생성한다.
        //storage를 추가하려면 상단에 gs:// 로 시작하는 스키마를 확인할 수 있다.
        FirebaseStorage fs = FirebaseStorage.getInstance("gs://swu2019winterproject-2100f.appspot.com/");
        //위에서 생성한 Firebase Storage 를 참조하는 storage 를 생성한다.
        StorageReference storageReference = fs.getReference();
        //위의 저장소를 참조하는 image 폴더를 저장해서 이미지를 올린다.
        final StorageReference imageref = storageReference.child("images/"+fileUri.getLastPathSegment());
        //실제파일 업로드 진행
        UploadTask uploadTask = imageref.putFile(fileUri);

        //다이얼로그 보이기
        PrefUtil.showProgress(InsertBoardActivity.this);


        //파일 업로드 성공/실패에 대한 콜백 메서드를 받아서 핸들링한다.
        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if(!task.isSuccessful()){
                    throw task.getException();
                }
                //이미지 파일이 올라간 실제 URL 주소를 addOnCompleteListener 에 리턴한다.
                return imageref.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                //이미지 업로드가 끝나면 호출되는 callBack 메서드
                //해야될 일 : Uploaded 된 이미지 URL과 사용자가 작성한
                //메모의 내용을 RealTime DB 에 업로드 시킨다.

                //새로운 이미지가 업로드가 끝나면 기존의 이미지는 지워중다.
                mStorage.getReference().child("images").child(mBoardBean.imgName).delete();

                DatabaseReference firebaseRef = mDatabase.getReference();
                String id = firebaseRef.push().getKey();//Key 를 ID로 사용

                //Database 에 저장한다.
                mBoardBean.imgUrl=task.getResult().toString();
                mBoardBean.imgName = fileUri.getLastPathSegment();//파일 이름 저장
                mBoardBean.title=edtTitle.getText().toString();
                mBoardBean.content=edtMemo.getText().toString();

                //userEmail 의 고유번호를 기준으로 사용자 데이터를 쌓기위해
                //고유키를 생성한다.
                String userUUID = getUserIdFromUUID(mBoardBean.userId);
                firebaseRef.child("memo").child(userUUID).child(mBoardBean.id).setValue(mBoardBean);

                Toast.makeText(InsertBoardActivity.this,"글 수정 성공",Toast.LENGTH_SHORT).show();

                //다이얼로그 숨기기
                PrefUtil.hideProgress(InsertBoardActivity.this);
                finish();
            }
        });
    }//end update

    //이메일의 문자 기준으로 고유번호를 추출
    public static String getUserIdFromUUID(String userEmail){
        long val = UUID.nameUUIDFromBytes(userEmail.getBytes()).getMostSignificantBits();
        return val+"";
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //카메라로부터 오는 데이터를 취득한다.
        if(resultCode==RESULT_OK){
            if(requestCode==REQUEST_IMAGE_CAPTURE){
                sendPicture(mPhotoPath);
            }
        }
    }
}
