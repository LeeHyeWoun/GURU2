package com.swu.leehyewoun.bean;

import java.io.Serializable;

public class BoardBean implements Serializable {
    public String id;       //게시글 고유 아이디
    public String userId;   //게시글 소유자 아이디
    public String imgUrl;   //이미지가 업로드된 경로
    public String imgName;  //이미지 파일 이름
    public String title;    //제목
    public String content;  //내용

    public BoardBean(){
        //RealDB 가 디폴트 생성자를 필요로 한다.
    }
}
