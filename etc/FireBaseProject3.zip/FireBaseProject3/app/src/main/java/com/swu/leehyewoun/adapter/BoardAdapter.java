package com.swu.leehyewoun.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.swu.leehyewoun.DownImgTask;
import com.swu.leehyewoun.InsertBoardActivity;
import com.swu.leehyewoun.R;
import com.swu.leehyewoun.bean.BoardBean;

import java.net.URL;
import java.util.List;

public class BoardAdapter extends BaseAdapter {

    private Context mContext;
    private List<BoardBean> mList;

    public BoardAdapter(Context context, List<BoardBean> list){
        mContext = context;
        mList=list;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.view_list_board,null);
        ImageView imgPhoto = convertView.findViewById(R.id.imgPhoto);
        TextView txtTitle = convertView.findViewById(R.id.txtTitle);
        TextView txtContents = convertView.findViewById(R.id.txtContents);
        Button btnModify = convertView.findViewById(R.id.btnModify);
        Button btnDelete = convertView.findViewById(R.id.btnDelete);

        final BoardBean bean = mList.get(position);

        //이벤트
        //수정
        btnModify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mContext,InsertBoardActivity.class);
                //데이터를 실어준다.
                i.putExtra(BoardBean.class.getName(),bean);
                mContext.startActivity(i);
            }
        });
        //삭제
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                String emailUUID = InsertBoardActivity.getUserIdFromUUID(email);
                //데이터 삭제
                FirebaseDatabase.getInstance().getReference().child("memo").child(emailUUID).child(bean.id).removeValue();
                //이미지 삭제
                FirebaseStorage.getInstance().getReference().child("images").child(bean.imgName).delete();
            }
        });

//        if(imgPhoto.getDrawable()==null){
        try {
            new DownImgTask(imgPhoto).execute(new URL(bean.imgUrl));
        }catch (Exception e){e.printStackTrace();}

//        }
        txtTitle.setText(bean.title);
        txtContents.setText(bean.content);

        return convertView;
    }
}
