package lesson.swu.swuclassexam;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NotiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti);

        Button btnNoti = findViewById(R.id.btnNoti);
        Button btnBigPictureNoti = findViewById(R.id.btnBigPictureNoti);
        Button btnBigTextNoti = findViewById(R.id.btnBigTextNoti);

        btnNoti.setOnClickListener(btnClick);
        btnBigPictureNoti.setOnClickListener(btnClick);
        btnBigTextNoti.setOnClickListener(btnClick);
    }

    private View.OnClickListener btnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            //오레오부터 바뀐 Noti 적용
            String channelId = "channel";
            String channelName = "Channel Name";

            NotificationManager notiMng =
                    (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

            //오레오 버젼부터 변경된 코드 적용
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                int importance = NotificationManager.IMPORTANCE_HIGH;
                NotificationChannel mChannel =
                        new NotificationChannel(channelId, channelName, importance);
                notiMng.createNotificationChannel(mChannel);
            }

            //다이얼로그 생성하듯이 빌더를 통해서 노티를 생성한다.
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(getApplicationContext(), channelId);

            int requestID = (int)System.currentTimeMillis();
            //노티 클릭시 이동하고 싶은 Activity 지정
            Intent notiIntent = new Intent(getApplicationContext(), CameraActivity.class);
            notiIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(),
                    requestID,
                    notiIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT
                    );

            //기본빌더 설정
            builder.setContentTitle("이것은 타이틀 이빈다.")
                .setContentText("이것은 실제 표시되는 컨텐츠 영역의 텍스트 입니다.")
                .setDefaults(Notification.DEFAULT_ALL) //알림 + 사운드진동 설정
                .setAutoCancel(true) //알림 터치후 노티삭제됨
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setSmallIcon(android.R.drawable.btn_star)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ico_del))
                .setContentIntent(pendingIntent);

            switch (v.getId()) {
                case R.id.btnNoti:
                    break;

                case R.id.btnBigPictureNoti:
                    Bitmap bmp =
                            BitmapFactory.decodeResource(getResources(), R.drawable.burger1);
                    NotificationCompat.BigPictureStyle bigStyle
                            = new NotificationCompat.BigPictureStyle(builder);
                    bigStyle.setBigContentTitle("Big Picture Content Title");
                    bigStyle.setSummaryText("This is Big Picture Notification Summary Text");
                    bigStyle.bigPicture(bmp);
                    builder.setStyle(bigStyle);
                    break;

                case R.id.btnBigTextNoti:
                    NotificationCompat.BigTextStyle bigTextStyle
                            = new NotificationCompat.BigTextStyle(builder);
                    bigTextStyle.setBigContentTitle("여긴 많은 Text가 써져도 보이는 곳이야!!!");
                    bigTextStyle.bigText("Mir's IT Blog address is timi.tistory.com , \n" +
                                "Welcome to the Mir's Blog!!! Nice To meet you \n" +
                                "밤새지 마란 말이야!!!!!");
                    builder.setStyle(bigTextStyle);
                    break;
            }//end switch case

            //최종적으로 노티를 실행하는 한다.
            Notification noti = builder.build();
            noti.number = 10; //미확인 노티갯수를 10개로 지정한다.
            // 10개이상 쌓이면
            // + 로 표시된다.

            notiMng.notify(requestID, noti);

        }
    };



}
