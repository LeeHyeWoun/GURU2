package lesson.swu.swuclassexam;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

import lesson.swu.swuclassexam.bean.JoinBean;
import lesson.swu.swuclassexam.util.PrefUtil;

public class Join1Activity extends AppCompatActivity {

    private EditText edtId, edtPw, edtName, edtEmail;
    private Button btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join1);

        edtId = findViewById(R.id.edtId);
        edtPw = findViewById(R.id.edtPw);
        edtName = findViewById(R.id.edtName);
        edtEmail = findViewById(R.id.edtEmail);
        btnJoin = findViewById(R.id.btnJoin);
        //회원가입버튼
        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Join1Activity.this);
                builder.setTitle("안내");
                builder.setIcon(R.drawable.eraser);
                builder.setMessage("회원 가입을 하시겠습니까?");
                builder.setCancelable(false); //밖깥영역 클릭시 다이얼로그 비표시 금지
                builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(Join1Activity.this, Join2Activity.class);
                        JoinBean jb = new JoinBean();
                        jb.setId( edtId.getText().toString() );
                        jb.setPw( edtPw.getText().toString() );
                        jb.setName( edtName.getText().toString() );
                        jb.setEmail( edtEmail.getText().toString() );
                        //인텐트에 데이터를 싣는다.
                        i.putExtra(JoinBean.class.getName(), jb);

                        //데이터를 저장한다. - Preference로 저장한다.
                        Gson gson = new Gson();
                        //class -> json 화 시키겠다.
                        String jsonStr = gson.toJson(jb);

                        Log.i("SWU", jsonStr);
                        //json 데이터를 저장한다.
                        PrefUtil.setData(getApplicationContext(), JoinBean.class.getName(), jsonStr);

                        startActivity(i);
                        finish();
                    }
                });

                builder.create().show();
            }
        });
    }
}
