package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class IntentDataViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_data_view);

        //저쪽에서 보낸 데이터를 받는다.
        String name = getIntent().getStringExtra("name");
        String age = getIntent().getStringExtra("age");

        TextView txtName = findViewById(R.id.txtName);
        TextView txtAge = findViewById(R.id.txtAge);

        //데이터 표시
        txtName.setText( name );
        txtAge.setText( age );

    }
}
