package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class ImgRotateActivity extends AppCompatActivity {


    private Button btnNext;
    private ImageView img1, img2, img3;
    private int mImgIdx = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_img_rotate);

        //1.첫번째 객체를 찾는다.
        btnNext = findViewById(R.id.btnNext);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);
    }

    @Override
    protected void onResume() {
        super.onResume();

        //2.원하는 객체에 이벤트를 등록한다.
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                img1.setVisibility(View.GONE);
                img2.setVisibility(View.GONE);
                img3.setVisibility(View.GONE);

                switch (mImgIdx){
                    case 1:
                        img1.setVisibility(View.VISIBLE);
                        mImgIdx++;
                        break;
                    case 2:
                        img2.setVisibility(View.VISIBLE);
                        mImgIdx++;
                        break;
                    case 3:
                        img3.setVisibility(View.VISIBLE);
                        mImgIdx = 1;
                }
            }
        });
    }
}
