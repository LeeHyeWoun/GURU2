package lesson.swu.swuclassexam;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

public class GPSActivity extends AppCompatActivity {

    private TextView txtDisp;
    private ToggleButton btnToggle;
    private LocationManager mLocManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);

        ActivityCompat.requestPermissions(GPSActivity.this,
                new String[]{
                        Manifest.permission.ACCESS_NETWORK_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, 0
                );

        txtDisp = findViewById(R.id.txtDisp);
        btnToggle = findViewById(R.id.btnToggle);

        //Location Provider 에서 정보를 얻어오는 방법
        //1.Location 을 사용하기 위한 권한을 얻는다.
        //  ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION
        //2.LocationManager를 통해서 원하는 Provider의 리스너 등록
        //3.GPS 테스트 ( 에뮬레이터에서는 확인만 가능하고 정확한 테스트는 안된다.)
        //4.실내에서는 GPS_PROVIDER를 요청해도응답이 없다.
        //해결방법은
        //  1.타이머를 설정하여 GPS_PROVIDER에서 일정시간 응답이 없을 경우
        //     NETWORK_PROVIDER로 전환한다.
        //  2.혹은, 둘다 한꺼번에 호출하여 들어오는 값을 확인한다.

        txtDisp.setText("위치정보 미수신중...");

        //LocationManager 객체를 얻어온다.
        mLocManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View v) {
                try {
                    if (btnToggle.isChecked()) {
                        txtDisp.setText("GPS 수신중...");
                        //GPS Provider 의 정보를 콜백 수신하도록 리스너 등록하기
                        mLocManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                                100, //마지막 콜백수신과의 최소 시간간격(millisec)
                                1, //마지막 콜백수신과의 최소 변경거리(m)
                                mLocationListener);
                        //Network Provider의 정보를 콜백 수신
                        mLocManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                                100,
                                1,
                                mLocationListener
                                );

                    } else {
                        txtDisp.setText("위치정보 미수신중...");
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

    }//end onCreate()


    private LocationListener mLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            //여기서 위치값이 갱신되면 이벤트가 발생한다.
            //값은 Location 객체 형태로 리턴되며, 좌표출력 방법은 다음과 같다.
            double longitude = location.getLongitude(); //경도
            double latitude = location.getLatitude(); //위도
            double altitude = location.getAltitude(); //고도
            float accuracy = location.getAccuracy(); //정확도
            String provider = location.getProvider(); //위치 제공자
            txtDisp.setText("위치정보: " + provider + "\n 위도: " + latitude
                + "\n경도: " + longitude + "\n고도: " + altitude
                + "\n정확도: " + accuracy
            );
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };


}
