package lesson.swu.swuclassexam;

import android.app.Dialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ProgressBar;

public class ProgressActivity extends AppCompatActivity {

    //프로그레스바 다이얼로그
    private ProgressBar mProgressBar;
    private Dialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        Button btnShowDlg1 = findViewById(R.id.btnShowDlg1);
        Button btnHideDlg1 = findViewById(R.id.btnHideDlg1);

        //다이얼로그 보이기 버튼 클릭
        btnShowDlg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showDialog();
                //AsyncTask
                new DlgTask().execute(); //실행

            }
        });

    }//end onCreate()

    //다이얼로그를 표시한다.
    private void showDialog() {
        if(mDialog == null) {
            mDialog = new Dialog(this);
        }

        //다이얼로그의 타이틀을 업앤다.
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        mDialog.setContentView(R.layout.view_progress);
        mDialog.setCancelable(false);
        mDialog.show();
    }

    private class DlgTask extends AsyncTask<Integer, Integer, Integer> {

        @Override
        protected Integer doInBackground(Integer... integers) {

            try {
                //5초간 잠잔다.
                Thread.sleep(5000);
            } catch (Exception e)  {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            //5초후 여기가 호출 -> doInBackGround() 가 호출해 준다.
            mDialog.hide(); //다이얼로그를 숨긴다.
        }
    }

}
