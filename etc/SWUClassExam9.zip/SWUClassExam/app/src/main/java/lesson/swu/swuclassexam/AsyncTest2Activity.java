package lesson.swu.swuclassexam;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class AsyncTest2Activity extends AppCompatActivity {

    private ProgressBar mPbrMain;
    private Button btnStart, btnStop;
    private TextView txtDisp;
    private PbrUpdaterTask mPbrUpdaterTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_async_test2);

        mPbrMain = findViewById(R.id.pbrMain);
        txtDisp = findViewById(R.id.txtDisp);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //AsyncTask 를 만들고 실행시킨다.
                mPbrUpdaterTask = new PbrUpdaterTask();
                mPbrUpdaterTask.execute();
            }
        });

        //프로그레스 종료!
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mPbrUpdaterTask != null
                        && !mPbrUpdaterTask.isStop()) {
                    mPbrUpdaterTask.stop();
                }
            }
        });

    }//end onCreate()

    //ProgressBar 를 비동기(Asyncronized)로 업데이트 해주는 클래스이다.
    class PbrUpdaterTask extends AsyncTask<Void, Integer, Integer> {

        private boolean isStop;

        public boolean isStop() {
            return isStop;
        }

        public void stop() {
            isStop = true;
        }

        @Override
        protected void onPreExecute() {
           //doInBackground() 메서드가 호출되기 직전에 호출되는 영역이다.
            //이 영역에서는 화면상의 View들의 값을 변경해도 된다.
            mPbrMain.setProgress(0);
            txtDisp.setText("0% - 실행준비중.");
        }

        @Override
        protected Integer doInBackground(Void... voids) {
            //실제로 화면상의 MainUIThread 와 별개로 움직이는 쓰레드 영역이다.
            //ex)ImageView의 image를 설정한다거나 하면 앱 죽는다.

            //1초에 한번씩 화면상의 프로그레스바를 업데이트 해준다.
            int i = 0;
            for(i=1; i<=100; i++) {
                if(isStop) {
                    break; //for 문을 빠져나간다.
                }
                try {
                    Thread.sleep(100); //1000 milliSecond  = 1초가 슬립
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //mPbrMain.setProgress(i); //이렇게 View단을 업데이트하는 순간
                //앱이 죽어버린다.
                publishProgress(i);
            }
            return i;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //실시간으로 doInBackground()에서 화면을 갱신하기 위해서 호출되는
            //메서드.
            //화면을 갱신할 수 있다.
            int curVal = values[0];
            mPbrMain.setProgress( curVal );
            txtDisp.setText(curVal + "% 업데이트중..." );
        }

        @Override
        protected void onPostExecute(Integer integer) {
            //doInBackground() 메서드가 종료되고
            // 최종적으로 화면에 업데이트를 해야될 사항들을 처리하는 영역
            if(integer == 100) {
                Toast.makeText(AsyncTest2Activity.this, "업데이트 완료!", Toast.LENGTH_SHORT).show();
                txtDisp.setText("100% 업데이트 완료!");
            }
        }
    };

}
