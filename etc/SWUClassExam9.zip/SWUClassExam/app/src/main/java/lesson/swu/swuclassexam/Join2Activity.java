package lesson.swu.swuclassexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import lesson.swu.swuclassexam.bean.JoinBean;

public class Join2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join2);

        TextView txtId = findViewById(R.id.txtId);
        TextView txtPw = findViewById(R.id.txtPw);
        TextView txtName = findViewById(R.id.txtName);
        TextView txtEmail = findViewById(R.id.txtEmail);
        Button btnLogin = findViewById(R.id.btnLogin);

        //인텐트로 부터 온 데이터를 취득한다.
        JoinBean joinBean = (JoinBean)
                            getIntent().getSerializableExtra(JoinBean.class.getName());
        //데이터를 표시한다.
        txtId.setText( joinBean.getId() );
        txtPw.setText( joinBean.getPw() );
        txtName.setText( joinBean.getName() );
        txtEmail.setText( joinBean.getEmail() );

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //로그인 화면으로
                Intent i = new Intent(Join2Activity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}
