package lesson.swu.swuclassexam.tab;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class PagerAdapter extends FragmentStatePagerAdapter {

    //탭의 갯수를 저장하고 있는 멤버변수
    private int mNumOfTab;

    //생성자
    public PagerAdapter(FragmentManager fm, int numOfTab) {
        super(fm);
        mNumOfTab = numOfTab;
    }

    @Override
    public Fragment getItem(int position) {
        //BaseAdapter에서 getView()메서드에 해당되는 메서드로써,
        //position 값이 곧! 현재 선택된 Tab의 Index번호를 나타낸다.

        switch (position) {
            case 0:
                Tab1Fragment tab1 = new Tab1Fragment();
                return tab1;
            case 1:
                Tab2Fragment tab2 = new Tab2Fragment();
                return tab2;
            case 2:
                Tab3Fragment tab3 = new Tab3Fragment();
                return tab3;
        }

        return null;
    }

    @Override
    public int getCount() {
        return mNumOfTab;
    }
}
