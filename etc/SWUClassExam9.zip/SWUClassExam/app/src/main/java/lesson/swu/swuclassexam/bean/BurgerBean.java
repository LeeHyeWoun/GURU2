package lesson.swu.swuclassexam.bean;

import java.io.Serializable;

public class BurgerBean implements Serializable {

    //타이틀 이미지
    private int imgTitle;
    //타이틀
    private String title;
    //설명
    private String desc;
    //가격
    private String price;


    public int getImgTitle() {
        return imgTitle;
    }

    public void setImgTitle(int imgTitle) {
        this.imgTitle = imgTitle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
