package lesson.swu.swuclassexam;

import android.Manifest;
import android.annotation.SuppressLint;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class GoogleMapActivity extends AppCompatActivity {

    private MapFragment mapFragment;
    private LatLng mCurPosLatLng;//현재 위치의 위도,경도를 저장하고 있는 변수

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_map);

        ActivityCompat.requestPermissions(GoogleMapActivity.this,
                new String[]{
                        Manifest.permission.ACCESS_NETWORK_STATE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION
                }, 0
        );

        mapFragment = (MapFragment)getFragmentManager().findFragmentById(R.id.map);
        Button btnGHM = findViewById(R.id.btnGHM);
        Button btnBusan = findViewById(R.id.btnBusan);
        Button btnSWU = findViewById(R.id.btnSWU);

        btnGHM.setOnClickListener(btnClick);
        btnBusan.setOnClickListener(btnClick);
        btnSWU.setOnClickListener(btnClick);

        //최초의 위치는 서울여대의 위도,경도로
        mCurPosLatLng = new LatLng(37.628345,127.090500 );

        //맵이 시작되고 준비가 완료되면 호출하는 콜백 메서드 등록
        mapFragment.getMapAsync(mapReadyCallBack);

    }//end onCreate()

    private OnMapReadyCallback mapReadyCallBack =new OnMapReadyCallback() {
        @SuppressLint("MissingPermission")
        @Override
        public void onMapReady(final GoogleMap googleMap) {
            //현재 위치 버튼 추가
            googleMap.setMyLocationEnabled(true);
            //맵 줌 인아웃 버튼 추가
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            //나침반 추가
            googleMap.getUiSettings().setCompassEnabled(true);

            //학교로 이동하도록 한다.
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(mCurPosLatLng));
            //줌인
            googleMap.animateCamera(CameraUpdateFactory.zoomTo(17));

            //맵에 마커를 찍는다
            googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                @Override
                public void onMapClick(LatLng latLng) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);//클릭한 곳의 위도 경도
                    markerOptions.title("클릭");
                    markerOptions.snippet("선택되었다.");
                    googleMap.addMarker(markerOptions);
                }
            });

            //앱의 마커를 지운다.
            googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    marker.remove();
                }
            });
        }
    };

    private View.OnClickListener btnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnGHM:
                    mCurPosLatLng = new LatLng(37.576028, 126.976795 );
                    break;
                case R.id.btnBusan:
                    mCurPosLatLng = new LatLng(35.159209, 129.160213 );
                    break;
                case R.id.btnSWU:
                    mCurPosLatLng = new LatLng(37.628345,127.090500 );
                    break;
            }
            mapFragment.getMapAsync(mapReadyCallBack);

        }
    };
}
