package lesson.swu.swuclassexam;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class IntentDataActivity extends AppCompatActivity {

    /***
     * 디지털미디어학과 이혜원_5조 DRED팀
     * 멀지 어떻게 잘할 수 있으려나~~~~~~~
     */
    private EditText edtName, edtAge;
    private Button btnSend;
// 나는야 개똥벌레 어쩔 수 없네

    //저기 개똥무덤이 내 집인걸

    //by.진아
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_data);

        //정윤혜

        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        btnSend = findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //데이터를 전송하기 위해서
                Intent i = new Intent(IntentDataActivity.this, IntentDataViewActivity.class);
                i.putExtra("name", edtName.getText().toString());
                i.putExtra("age", edtAge.getText().toString());
                startActivity(i);
            }
        });
    }


}
