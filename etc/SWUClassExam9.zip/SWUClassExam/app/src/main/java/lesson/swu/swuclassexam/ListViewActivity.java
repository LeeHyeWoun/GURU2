package lesson.swu.swuclassexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import lesson.swu.swuclassexam.adapter.BurgerAdapter;
import lesson.swu.swuclassexam.bean.BurgerBean;

public class ListViewActivity extends AppCompatActivity {

    private ListView lstMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        lstMain = findViewById(R.id.lstMain);

        BurgerBean b1 = new BurgerBean();
        b1.setImgTitle( R.drawable.burger1 );
        b1.setTitle( "치킨버거" );
        b1.setDesc("치킨다리가 2개나 들어있는 초대박 아이템");
        b1.setPrice("200,000원");

        BurgerBean b2 = new BurgerBean();
        b2.setImgTitle( R.drawable.burger2 );
        b2.setTitle( "소고기 무한리필 버거" );
        b2.setDesc("먹다가 배터져도 책임안짐. 소고기 무한리필");
        b2.setPrice("1,000,000원");

        List<BurgerBean> burgerList = new ArrayList<BurgerBean>();
        burgerList.add(b1);
        burgerList.add(b2);

        //Adapter를 생성한다.
        BurgerAdapter burgerAdapter = new BurgerAdapter(ListViewActivity.this, burgerList);

        //Adapter를 ListView 에 부착 시킨다.
        lstMain.setAdapter( burgerAdapter );

    }
}
