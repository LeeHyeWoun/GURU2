package lesson.swu.swuclassexam;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CameraActivity extends AppCompatActivity {

 	///leesg
	///dsflkfjaslfjlskafjlksad 나는 커밋된줄도 모르고 수정하고 있다.
    //내가 바보는 아니고, 머지를 정확히 하면 해결될것이라고
    public static final int REQ_CAMERA = 2222;

    private Button btnCamera;
    private ImageView imgCamera;
    private String mCurrentPhotoPath;
    private Uri mImageUri;

    @Override    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        //코드상으로 명시적으로 퍼미션을 요청하지 않으면 롤리팝 이상 버젼에서 실행되지 않는다.
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA
                }, 1);

        btnCamera = findViewById(R.id.btnCamera);
        imgCamera = findViewById(R.id.imgCamera);

        //카메라 클릭
        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureCamera(); //메서드 호출
            }
        });

    }//end onCreate()


    private void captureCamera() {

        String state = Environment.getExternalStorageState();
        //외장 메모리 검사
        if(Environment.MEDIA_MOUNTED.equals(state)) {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            if( takePictureIntent.resolveActivity(getPackageManager()) != null ) {
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (Exception e) {
                    Log.e("SWU", e.toString());
                }

                if(photoFile != null) {
                    //getUriForFile의 두번째 인자는 Manifest provider의 authorities 와 일치해야 함.
                    Uri providerURI =
                            FileProvider.getUriForFile(this, getPackageName(), photoFile);
                    mImageUri = providerURI;

                    //인텐트에 전달할 때는 FileProvider의 Return값이 content://로만,
                    //providerURI의 값에 카메라 데이터를 넣어 보냄.
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, providerURI);

                    //롤리팝 이상버젼에서만 카메라가 기동된다.
                    startActivityForResult(takePictureIntent, 2222);
                }
            }
        }//end if

    }//end captureCamera()

    //카메라를 찍기전에 카메라로 찍은 이미지가 저장될 파일을 생성-반환 한다.
    private File createImageFile() throws Exception {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + ".jpg";
        File imageFile = null;
        File storageDir =
                new File(Environment.getExternalStorageDirectory() + "/Pictures/", "gyeom");

        if(!storageDir.exists()) {
            Log.d("SWU", storageDir.toString());
            storageDir.mkdirs();
        }

        imageFile = new File(storageDir, imageFileName);
        mCurrentPhotoPath = imageFile.getAbsolutePath();

        return imageFile;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case REQ_CAMERA:
                if (resultCode == Activity.RESULT_OK) {
                    try {
                        //카메라로부터 넘어온 데이터를 받는다.
                        imgCamera.setImageURI((mImageUri));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

        }

    }

}
