package lesson.swu.swuclassexam.tab;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import lesson.swu.swuclassexam.R;

public class TabMainActivity extends AppCompatActivity {

    private TabLayout mTabLayout;
    private ViewPager mPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_main);

        mTabLayout = findViewById(R.id.tabLayout);
        mPager = findViewById(R.id.pager);

        //탭을 추가한다.(동적으로)
        mTabLayout.addTab( mTabLayout.newTab().setText("Tab 1") );
        mTabLayout.addTab( mTabLayout.newTab().setText("Tab 2") );
        mTabLayout.addTab( mTabLayout.newTab().setText("Tab 3") );

        //탭의 가로 전체 사이즈 지정
        mTabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);

        //탭 아이콘 추가
        mTabLayout.getTabAt(0).setIcon(R.drawable.ico_del); //최대 48x48 pixel
        mTabLayout.getTabAt(1).setIcon(R.drawable.ico_refresh);
        mTabLayout.getTabAt(2).setIcon(R.drawable.eraser);

        //ViewPager는 Adapter를 통해서 Page(=Fragment)를 관리한다.
        PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(),
                mTabLayout.getTabCount());
        mPager.setAdapter(adapter);

        //TabLayout 과 ViewPager를 서로 연결 시킨다
        //ViewPager가 움직였을 때, 탭이 바뀌게끔 한다.
        mPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));

        //TabLayout이 움직일때 ViewPager가 움직이도록 연결시킨다.
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                //현재 사용자가 클릭한 탭의 이벤트가 실행된다.
                mPager.setCurrentItem( tab.getPosition() );
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }
            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
